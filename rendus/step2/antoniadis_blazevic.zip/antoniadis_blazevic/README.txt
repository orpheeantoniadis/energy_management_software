Pour générer l'apidoc :
- ouvrir un terminal dans le repertoire apidoc
- apidoc -i ../python

Pour lancer le serveur REST
- mettre les bon identifiants de la bdd dans le fichier database.ini
- mettre l'adresse où lancer le serveur REST dans rest_server.ini (localhost par défaut)